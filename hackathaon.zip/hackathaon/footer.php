<?php
// footer.php
?>

<footer class="bg-gray-800 border-t border-red-500/10 mt-16">
    <div class="container mx-auto max-w-6xl p-4 sm:p-6 md:p-8 text-center text-gray-500">
        <p>&copy; <?php echo date("Y"); ?> NodeZer0. All rights reserved.</p>
    </div>
</footer>

</body>
</html>
